// src/components/Message/index.js
import Message from "./Message.jsx";

export default Message;
