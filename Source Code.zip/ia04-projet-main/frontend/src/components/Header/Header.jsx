import React from "react";
import "./Header.scss";

const Header = () => (
  <div className="header">
    <h2>Dilemme du prisonnier itéré</h2>
  </div>
);

export default Header;
